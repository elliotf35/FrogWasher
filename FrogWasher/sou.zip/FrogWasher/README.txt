List of free assets for art

Tiles:
https://assetstore.unity.com/packages/2d/environments/pixel-art-woods-tileset-and-background-280066
https://ohnoponogames.itch.io/retro-cloud-tileset
https://assetstore.unity.com/packages/2d/environments/pixel-skies-demo-background-pack-226622
https://opengameart.org/content/sunset-temple-tiles

Character:
https://luizmelo.itch.io/medieval-king-pack
https://www.spriters-resource.com/ds_dsi/pvszds/sheet/214073/

Enemies:
https://nofool.itch.io/frog-character
https://www.spriters-resource.com/fullview/144752/
https://www.spriters-resource.com/fullview/169120/
https://www.spriters-resource.com/neo_geo_ngcd/bluesjourneyraguy/sheet/169120/

Lightning Effect For Final Boss:
https://www.freepik.com/free-vector/cartoon-shock-animation-frames_14140646.htm#query=lightning%20sprite&position=1&from_view=keyword&track=ais&uuid=faa6948b-ff9a-449b-805a-4843e3dd55a1

https://www.freepik.com/free-vector/lightning-electric-effect-light-thunder-vector-isolated-transparent-background-3d-thunderbolt-shock-power-element-set-magic-discharge-neon-ground-crack-laser-strike-texture-illustration_55920316.htm#query=lightning%20sprite&position=49&from_view=keyword&track=ais&uuid=3aaa83e0-3a3f-479e-89ae-c8dc93c94250

Sound Effects:
https://www.youtube.com/watch?v=f4A1-Dyyljw
https://www.youtube.com/watch?v=P_6rqvdRP98
https://www.youtube.com/watch?v=kxjqY9aIryE
https://www.youtube.com/watch?v=q3nwbF1A20s
https://www.youtube.com/watch?v=JnUEfFYegN0
https://www.youtube.com/watch?v=Ne0L2Cvdexo
https://www.youtube.com/watch?v=Msx3flEqeq8
https://www.youtube.com/watch?v=cdKC9E_kQ70
https://www.youtube.com/watch?v=e0LdK1ol1po
https://www.youtube.com/watch?v=QjzJERfJqC4
https://www.youtube.com/watch?v=b4B6CHjhNXk

Menu Buttons:
https://www.freepik.com/free-vector/dark-set-game-stone-button-elements-progress-bar-bright-different-forms-buttons-games-app_13466791.htm#query=game%20pause%20ui&position=1&from_view=keyword&track=ais&uuid=831d378b-6e44-4c27-a6a0-641bd3c9cfa4

https://www.freepik.com/free-vector/wooden-cartoon-game-interface-collection_25896897.htm#query=game%20pause%20ui&position=23&from_view=keyword&track=ais&uuid=b8bca347-8735-4e20-b1ea-d0ce965dbbb6

Music Sound Tracks:
Jeremy Blake - Powerup! https://www.youtube.com/watch?v=l7SwiFWOQqM&list=PLwJjxqYuirCLkq42mGw4XKGQlpZSfxsYd&index=5&ab_channel=FreeMusic
Joshua McLean - Mountain Trials  https://www.youtube.com/watch?v=L_OYo2RS8iU&list=PLwJjxqYuirCLkq42mGw4XKGQlpZSfxsYd&index=8&ab_channel=FreeMusic
Jorge Hernandez - Chopsticks https://www.youtube.com/watch?v=G-FGiICah8Q&list=PLwJjxqYuirCLkq42mGw4XKGQlpZSfxsYd&index=9&ab_channel=FreeMusic
Monplaisir - Soundtrack https://www.youtube.com/watch?v=Ddrs6FXIJ-g&list=PLwJjxqYuirCLkq42mGw4XKGQlpZSfxsYd&index=18
The Whole Other - 8-Bit Dreamscape https://www.youtube.com/watch?v=KvDcTXEfdVs&list=PLwJjxqYuirCLkq42mGw4XKGQlpZSfxsYd&index=20
William Rosati - Floating Also https://www.youtube.com/watch?v=HHYOBwzT4u4&list=PLwJjxqYuirCLkq42mGw4XKGQlpZSfxsYd&index=23
Donkey Kong Country - Aquatic Ambience https://www.youtube.com/watch?v=-5rAjOjTGtc
DM DOKURO "Scourge of The Universe" - Theme of Devourer of Gods  https://www.youtube.com/watch?v=-Syn1mJVt7U
